# cut_mailmail.py
# Ninell Oldenburg
# University of Potsdam
# 09/09/2019
# Project: Oh my Guardian

import sys

# class for parsing of special signs
class Cut:
    def __init__(self):
        self
    
    def cut_mail(self,string):
        
        if type(string) == str:
            
            string = string.replace('point','.')
            string = string.replace('dot','.')
            string = string.replace('minus','-')
            string = string.replace('underscore','_')

        return string.replace('+','')


if __name__ == "__main__":
    test = Cut()
    print(test.cut_mail(sys.argv[1]))
