# send_mail.py
# Ninell Oldenburg
# University of Potsdam
# 08/10/2019
# Project: Oh my Guardian

import smtplib
import sys
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# class for sending a mail through SMTP-server from default mail adress
class Mail:
    # Input: mail file and receiving mail adress
    def __init__(self,textfile,to_mail):
        self.text = textfile
        self.receives = to_mail
        self.msg = MIMEText(textfile.encode('utf-8'), 'plain', 'utf-8')
        if type(to_mail) == str: self.to_mail = to_mail
    
    # function for constructing the mail with default subject and sender adress
    def make_mail(self):
        self.msg = MIMEMultipart('alternative')
        self.msg['Subject'] = 'Your Alexa Search'
        self.msg['From'] = 'oh-my-guardian@gmx.de'
        self.msg['To'] = self.receives
    
        self.msg.attach(MIMEText(self.text, 'plain'))
    
    # function for connecting to the SMTP-server and sending the mail
    def send_mail(self):
        server = smtplib.SMTP('mail.gmx.net', 587)

        server.ehlo()
        server.starttls()
        server.login("oh-my-guardian@gmx.de", "MyGuardianPassword")

        # server.set_debuglevel(1)
        
        self.make_mail()

        server.sendmail('oh-my-guardian@gmx.de', self.receives, self.msg.as_string())
        server.quit()

if __name__ == "__main__":
    test = Mail(sys.argv[1],sys.argv[2])
    test.send_mail()
