# API-Request
# 08/03/2019
# Ninell Oldenburg, University of Potsdam
# Project: Oh My Guardian

import sys
import requests
import json

# class for the API request returning a JSON file
class API:
    # init the class with the request word/words and the mode
    def __init__(self,income_request,mode):
        if type(income_request) != str:
            raise ValueError('Request has to be string type') # check if income request if a string
        if not mode in ['content','tag']:
            raise ValueError('Mode variable has to be either "content" or "tag"') # and if the mode is valid
        self.mode = mode
        self.request = income_request
        self.api_url_base = 'https://content.guardianapis.com/'
        # more or less private key which was created by the website
        self.api_key = "0ae2a438-e39d-4715-95af-585ec6f390ee"

    # function to actually get the data from the API
    def get_data(self):
        r = requests.get(self.form_request())
        return r.json()

    # form a proper request to access the API depending on which mode is used
    def form_request(self):
        request = self.api_url_base
        
        # at this point the request differ completely from each other
        if self.mode == 'content': # you'll find different articles here
            request += 'search'
        
        elif self.mode == 'tag': # you'll find different sections here
            request += 'tags'

        request += '?q=' + self.request + '&api-key=' + self.api_key
        return request

    # fill the entry-dict with sections as keys and a list of (webTitle,webUrl) tuples
    def read_properly(self,jsonfile):
        total = jsonfile['response']['total']
        section_names = {}
        
        to_append = ()
        
        section_names['mode'] = self.mode
        section_names['keyword'] = self.request
        
        for response,entry in jsonfile.items():
            for found in entry['results']:
            
                # if mode == 'content' you'll find a date; if mode == 'tag' not
                if self.mode == "content":
                    date = found['webPublicationDate']
                    to_append = (found['webTitle'],found['webUrl'],date[:(date.find('T'))])
                else:
                    to_append = (found['webTitle'],found['webUrl'])
                
                # depending on if the section already exists, add the entry to the read- and iterable dict
                if 'sectionName' in found.keys():
                    if found['sectionName'] in section_names.keys():
                        section_names[found['sectionName']].append(to_append)
                    else:
                        section_names[found['sectionName']] = [to_append]
    
        return json.dumps(section_names)

# function to test the classes via the shell
if __name__ == "__main__":
    if len(sys.argv) != 3 :
        print('0')
    test = API(sys.argv[1],sys.argv[2])
    print(test.read_properly(test.get_data()))

