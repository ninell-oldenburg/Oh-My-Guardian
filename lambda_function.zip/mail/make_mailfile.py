# make_mailmail.py
# Ninell Oldenburg
# University of Potsdam
# 08/10/2019
# Project: Oh my Guardian

import json
import sys
from datetime import datetime
from mail.api_request import API

# class for writing a proper mail file
class Write:
    def __init__(self,file):
        # takes json file as input
        self.articles = json.loads(file)
        self.mode = self.articles['mode']
        self.keyword = self.articles['keyword']

    # writes readable mail and returns it as a string
    def make_mail(self):
        text = "Hi!\n\nYou were searching for the {} '{}' \n\n".format(self.mode,self.keyword)
        text += "This is what I found for you: \n\n"
        for section,entrylist in self.articles.items():
            if not (section == 'mode' or section == 'keyword'):
                text += "In section '{}': \n".format(section)
                for entry in entrylist:
                    if len(entry) == 2:
                        text += "Keyword: {}\n".format(entry[0])
                    if len(entry) > 2:
                        text += "Title: {}\n".format(entry[0])
                        text += "From: {}\n".format(datetime.strptime(entry[2],"%Y-%m-%d").strftime('%d/%m/%Y'))
                    text += "Web URL: {}\n\n".format(entry[1])
        return text

if __name__ == '__main__':
    test = API(sys.argv[1],sys.argv[2])
    write = Write(test.read_properly(test.get_data()))
    print(write.make_mail())
